# Notices

chanceify™ is licensed under the GNU Affero General Public License v3.0
(see [LICENSE](LICENSE)).

It began from Spotifast by Carmine Paolino, which is released under the MIT
License. Its notice is kept here, as that license requires:

```
MIT License

Copyright (c) 2026 Carmine Paolino

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

Playback comes from [librespot](https://github.com/librespot-org/librespot)
(MIT). Spotify, Last.fm and Discord are trademarks of their owners; chanceify
is not affiliated with them.

The language flags in `assets/flags/` are from
[flag-icons](https://github.com/lipis/flag-icons) by Panayiotis Lipiridis
(MIT License, Copyright (c) 2013 Panayiotis Lipiridis).
