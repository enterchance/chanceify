use super::*;

struct Fixture {
    ctx: Context,
    controller: Autoscroll,
    enabled: bool,
    tall: bool,
    second: bool,
    frame_number: u64,
    frame_rate: f64,
    continuous: bool,
    areas: Vec<(Id, Rect)>,
    rows: Vec<Rect>,
    buttons: Vec<Rect>,
    inputs: Vec<Rect>,
    text: String,
    tag_lyrics: bool,
    following: bool,
}

impl Fixture {
    fn new() -> Self {
        Self::at_rate(60.0)
    }

    fn at_rate(frame_rate: f64) -> Self {
        let mut fixture = Self {
            ctx: Context::default(),
            controller: Autoscroll::default(),
            enabled: true,
            tall: true,
            second: true,
            frame_number: 0,
            frame_rate,
            continuous: false,
            areas: Vec::new(),
            rows: Vec::new(),
            buttons: Vec::new(),
            inputs: Vec::new(),
            text: String::new(),
            tag_lyrics: false,
            following: true,
        };
        fixture.frame(vec![], true);
        fixture.frame(vec![], true);
        fixture
    }

    fn frame(&mut self, events: Vec<egui::Event>, focused: bool) {
        let ctx = self.ctx.clone();
        self.frame_number += 1;
        self.areas.clear();
        self.rows.clear();
        self.buttons.clear();
        self.inputs.clear();
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(Pos2::ZERO, egui::vec2(560.0, 340.0))),
                time: Some(self.frame_number as f64 / self.frame_rate),
                events,
                focused,
                ..Default::default()
            },
            |ui| {
                if self.continuous {
                    ctx.request_repaint();
                }
                self.controller.begin(&ctx, self.enabled);
                ui.put(
                    Rect::from_min_size(egui::pos2(10.0, 275.0), egui::vec2(180.0, 35.0)),
                    egui::Button::new("Outside control"),
                );
                for index in 0..if self.second { 2 } else { 1 } {
                    let rect = Rect::from_min_size(
                        egui::pos2(10.0 + index as f32 * 280.0, 10.0),
                        egui::vec2(240.0, 220.0),
                    );
                    let mut child = ui.new_child(
                        egui::UiBuilder::new()
                            .id_salt(index)
                            .max_rect(rect)
                            .layout(egui::Layout::top_down(egui::Align::Min)),
                    );
                    let output = show(
                        &mut child,
                        ScrollArea::vertical()
                            .id_salt(index)
                            .max_height(220.0)
                            .animated(false),
                        egui::Vec2b::new(false, true),
                        |ui| {
                            let response =
                                ui.add_sized([220.0, 36.0], egui::Button::new("Song row"));
                            row(ui, &response);
                            self.rows.push(response.rect);
                            let button = ui.add_sized(
                                [200.0, 30.0],
                                egui::Button::new("A control inside the list"),
                            );
                            self.buttons.push(button.rect);
                            let input = ui.add(
                                egui::TextEdit::singleline(&mut self.text).desired_width(200.0),
                            );
                            self.inputs.push(input.rect);
                            if self.tall {
                                ui.allocate_space(egui::vec2(220.0, 700.0));
                            }
                        },
                    );
                    if self.tag_lyrics {
                        lyrics(&child, output.id);
                    }
                    self.areas.push((output.id, output.inner_rect));
                }
                let outcome = self.controller.finish(&ctx, self.enabled);
                if outcome.stop_following_lyrics {
                    self.following = false;
                }
            },
        );
        output.textures_delta.clear();
    }

    fn middle(&mut self, position: Pos2) {
        self.frame(
            vec![
                egui::Event::PointerMoved(position),
                button(position, egui::PointerButton::Middle, true),
            ],
            true,
        );
        self.frame(
            vec![button(position, egui::PointerButton::Middle, false)],
            true,
        );
    }

    fn offsets(&self) -> Vec<Vec2> {
        self.areas
            .iter()
            .map(|(id, _)| {
                egui::scroll_area::State::load(&self.ctx, *id)
                    .unwrap()
                    .offset
            })
            .collect()
    }
}

fn button(pos: Pos2, button: egui::PointerButton, pressed: bool) -> egui::Event {
    egui::Event::PointerButton {
        pos,
        button,
        pressed,
        modifiers: egui::Modifiers::NONE,
    }
}

#[test]
fn scrolling_stays_with_the_starting_list_when_the_pointer_crosses_another_pane() {
    let mut f = Fixture::new();
    f.middle(f.rows[0].center());
    assert!(f.controller.active(), "the list row must arm the gesture");
    let across = egui::pos2(400.0, 200.0);
    for _ in 0..4 {
        f.frame(vec![egui::Event::PointerMoved(across)], true);
    }
    let offsets = f.offsets();
    assert!(offsets[0].y > 0.0);
    assert_eq!(
        offsets[1],
        Vec2::ZERO,
        "the pointer must not transfer scroll ownership"
    );
}

#[test]
fn only_a_scrollable_background_or_list_row_can_arm() {
    for target in 0..4 {
        let mut f = Fixture::new();
        let position = match target {
            0 => f.buttons[0].center(),
            1 => f.inputs[0].center(),
            2 => egui::pos2(100.0, 290.0),
            _ => egui::pos2(500.0, 320.0),
        };
        f.middle(position);
        assert!(
            !f.controller.active(),
            "control, input or chrome {target} must not arm"
        );
        assert!(f.offsets().iter().all(|offset| *offset == Vec2::ZERO));
    }
    let mut f = Fixture::new();
    f.middle(egui::pos2(100.0, 180.0));
    assert!(
        f.controller.active(),
        "blank space inside an overflowing list is eligible"
    );
    let mut f = Fixture::new();
    f.tall = false;
    f.frame(vec![], true);
    f.frame(vec![], true);
    f.middle(f.rows[0].center());
    assert!(
        !f.controller.active(),
        "a list that fits must not claim the gesture"
    );
}

#[test]
fn focus_loss_disabling_and_disappearing_owner_cancel_without_more_movement() {
    for reason in 0..3 {
        let mut f = Fixture::new();
        f.middle(f.rows[1].center());
        f.frame(
            vec![egui::Event::PointerMoved(egui::pos2(400.0, 180.0))],
            true,
        );
        assert!(f.controller.active());
        if reason == 1 {
            f.enabled = false;
        }
        if reason == 2 {
            f.second = false;
        }
        f.frame(vec![], reason != 0);
        assert!(!f.controller.active());
        let stopped = f.offsets();
        for _ in 0..3 {
            f.frame(vec![], true);
        }
        assert_eq!(f.offsets(), stopped);
    }
}

#[test]
fn escape_clicks_and_wheel_stop_the_gesture_without_immediately_rearming_it() {
    for reason in 0..4 {
        let mut f = Fixture::new();
        let anchor = f.rows[0].center();
        f.middle(anchor);
        assert!(f.controller.active());
        let event = match reason {
            0 => egui::Event::Key {
                key: egui::Key::Escape,
                physical_key: None,
                pressed: true,
                repeat: false,
                modifiers: egui::Modifiers::NONE,
            },
            1 => button(anchor, egui::PointerButton::Middle, true),
            2 => button(anchor, egui::PointerButton::Primary, true),
            _ => egui::Event::MouseWheel {
                unit: egui::MouseWheelUnit::Point,
                delta: egui::vec2(0.0, -20.0),
                phase: egui::TouchPhase::Move,
                modifiers: egui::Modifiers::NONE,
            },
        };
        f.frame(vec![event], true);
        assert!(
            !f.controller.active(),
            "cancellation {reason} must not rearm in the same frame"
        );
    }
}

#[test]
fn a_middle_click_and_small_pointer_movements_do_not_nudge_the_list() {
    let mut f = Fixture::new();
    let anchor = f.rows[0].center();
    f.middle(anchor);
    for y in [0.0, 5.0, 11.0] {
        f.frame(
            vec![egui::Event::PointerMoved(anchor + egui::vec2(50.0, y))],
            true,
        );
    }
    assert_eq!(f.offsets(), vec![Vec2::ZERO, Vec2::ZERO]);
    f.frame(
        vec![egui::Event::PointerMoved(anchor + egui::vec2(0.0, 40.0))],
        true,
    );
    assert!(f.offsets()[0].y > 0.0);
}

#[test]
fn a_nested_horizontal_shelf_keeps_its_axis_and_never_scrolls_the_outer_page() {
    let ctx = Context::default();
    let mut controller = Autoscroll::default();
    let mut frame = 0;
    let mut render = |events| {
        frame += 1;
        let mut ids = [Id::NULL; 2];
        let mut first = Pos2::ZERO;
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(Pos2::ZERO, egui::vec2(500.0, 340.0))),
                events,
                time: Some(frame as f64 / 60.0),
                ..Default::default()
            },
            |ui| {
                controller.begin(&ctx, true);
                let outer = show(
                    ui,
                    ScrollArea::vertical().id_salt("outer").animated(false),
                    egui::Vec2b::new(false, true),
                    |ui| {
                        let shelf = show(
                            ui,
                            ScrollArea::horizontal().id_salt("shelf").animated(false),
                            egui::Vec2b::new(true, false),
                            |ui| {
                                ui.horizontal(|ui| {
                                    for index in 0..12 {
                                        let response = ui.add_sized(
                                            [160.0, 60.0],
                                            egui::Button::new(format!("Album {index}")),
                                        );
                                        row(ui, &response);
                                        if index == 0 {
                                            first = response.rect.center();
                                        }
                                    }
                                });
                            },
                        );
                        ids[0] = shelf.id;
                        ui.allocate_space(egui::vec2(200.0, 900.0));
                    },
                );
                ids[1] = outer.id;
                controller.finish(&ctx, true);
            },
        );
        output.textures_delta.clear();
        let offsets = ids.map(|id| egui::scroll_area::State::load(&ctx, id).unwrap().offset);
        (first, controller.active(), offsets)
    };
    render(vec![]);
    let (anchor, _, _) = render(vec![]);
    let (_, active, _) = render(vec![
        egui::Event::PointerMoved(anchor),
        button(anchor, egui::PointerButton::Middle, true),
    ]);
    assert!(active);
    render(vec![button(anchor, egui::PointerButton::Middle, false)]);
    let (_, active, offsets) = render(vec![egui::Event::PointerMoved(egui::pos2(450.0, 280.0))]);
    assert!(active);
    assert!(offsets[0].x > 0.0);
    assert_eq!(offsets[0].y, 0.0);
    assert_eq!(offsets[1], Vec2::ZERO);
}

#[test]
fn lyric_following_stops_only_when_a_scrollable_lyrics_area_accepts_the_gesture() {
    for tall in [false, true] {
        let mut f = Fixture::new();
        f.tag_lyrics = true;
        f.tall = tall;
        f.frame(vec![], true);
        f.frame(vec![], true);
        f.middle(f.rows[0].center());
        assert_eq!(f.controller.active(), tall);
        assert_eq!(f.following, !tall);
    }
}

#[test]
fn losing_focus_while_drawing_is_suspended_cannot_resume_autoscroll_on_return() {
    let mut f = Fixture::new();
    f.middle(f.rows[0].center());
    f.frame(
        vec![egui::Event::PointerMoved(egui::pos2(100.0, 180.0))],
        true,
    );
    assert!(f.controller.active());
    let stopped = f.offsets();
    f.frame_number += 1;
    let mut output = f.ctx.run_ui(
        egui::RawInput {
            focused: false,
            time: Some(f.frame_number as f64 / 60.0),
            ..Default::default()
        },
        |ui| {
            assert!(f.controller.cancel_if_unfocused(ui.ctx()));
        },
    );
    output.textures_delta.clear();
    f.frame(vec![], true);
    assert!(!f.controller.active());
    assert_eq!(f.offsets(), stopped);
}

#[test]
fn extra_redraws_do_not_make_the_same_one_second_gesture_scroll_further() {
    let distance = |rate: u32| {
        let mut f = Fixture::at_rate(f64::from(rate));
        f.continuous = true;
        f.frame(vec![], true);
        let anchor = f.rows[0].center();
        f.middle(anchor);
        for _ in 0..rate {
            f.frame(
                vec![egui::Event::PointerMoved(anchor + egui::vec2(0.0, 42.0))],
                true,
            );
        }
        f.offsets()[0].y
    };
    let ordinary = distance(60);
    let frequent = distance(2000);
    assert!(ordinary > 0.0);
    assert!(
        (ordinary - frequent).abs() < 1.0,
        "equal time and pointer distance must give equal scrolling: {ordinary} vs {frequent}"
    );
}
