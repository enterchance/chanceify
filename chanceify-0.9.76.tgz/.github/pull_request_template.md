## Why

What user problem does this solve, and why does it belong in Spotifast?

## What changed

Describe the change. Link the issue, if there is one.

## Verification

List the commands and platforms you actually tested. Include before/after
screenshots or a recording for UI changes.

- [ ] I kept this pull request to one concern.
- [ ] I added or updated tests for behaviour that can regress.
- [ ] I ran formatting, Clippy, and the relevant tests locally.
- [ ] I updated documentation for user-visible behaviour, settings, files, or network access.
- [ ] I understand and take responsibility for every submitted line, including AI-assisted code.
